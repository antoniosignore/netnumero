// Copyright 2011 Google Inc. All rights reserved.
package com.google.appengine.api.search;

/**
 * Thrown to indicate that a search service failure occurred while performing
 * a list documents request.
 *
 * @deprecated As of 1.6.6, replaced by {@link ListException}.
 */
@Deprecated
public class ListDocumentsException extends SearchBaseException {
  static final long serialVersionUID = -3978896724020409268L;

  /**
   * Constructs an exception when some error occurred in
   * the search service when processing a list documents request.
   *
   * @param message the error detail associated with the failure
   */
  public ListDocumentsException(String message) {
    this(new OperationResult(StatusCode.INTERNAL_ERROR, message));
  }

  /**
   * Constructs an exception when some error occurred in
   * the search service when processing a list documents request.
   *
   * @param operationResult the error code and message detail associated with
   * the failure
   */
  public ListDocumentsException(OperationResult operationResult) {
    super(operationResult);
  }
}
