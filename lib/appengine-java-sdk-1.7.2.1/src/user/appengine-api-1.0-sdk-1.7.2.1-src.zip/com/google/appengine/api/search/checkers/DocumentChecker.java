// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.appengine.api.search.checkers;

import com.google.appengine.api.search.Util;
import com.google.apphosting.api.search.DocumentPb;

/**
 * Checks values of a {@link com.google.appengine.api.search.Document}.
 *
 */
public final class DocumentChecker {

  private static final long MILLIS_UP_TO_1ST_JAN_2011 = 1293840000000L;

  /**
   * The maximum length of a document id.
   */
  public static final int MAXIMUM_DOCUMENT_ID_LENGTH = 500;
  public static final int MAXIMUM_DOCUMENT_LENGTH = 1 << 20;

  /**
   * Checks whether a document id is valid. A document id is a
   * non-null ASCII visible printable string of
   * {@literal #MAXIMUM_DOCUMENT_ID_LENGTH} characters which does not start
   * with '!' which is reserved for system documents.
   *
   * @param documentId the document id to check
   * @return the checked document id
   * @throw IllegalArgumentException if the document id is invalid
   */
  public static String checkDocumentId(String documentId) {
    Preconditions.checkArgument(!Util.isNullOrEmpty(documentId), "Document id is null or empty");
    Preconditions.checkArgument(documentId.length() <= MAXIMUM_DOCUMENT_ID_LENGTH,
        "Document id is longer than %d: %s", MAXIMUM_DOCUMENT_ID_LENGTH, documentId);
    Preconditions.checkArgument(IndexChecker.isAsciiVisiblePrintable(documentId),
        "documentId must be ASCII visible printable: %s", documentId);
    Preconditions.checkArgument(!IndexChecker.isReserved(documentId),
        "documentId must not start with !: %s", documentId);
    return documentId;
  }

  /**
   * Checks whether a {@link DocumentPb.Document} has a valid set
   * of fields.
   *
   * @param pb the {@link DocumentPb.Document} protocol buffer to check
   * @return the checked document
   * @throws IllegalArgumentException if some field is invalid such as
   * document id or fields
   */
  public static DocumentPb.Document checkValid(DocumentPb.Document pb) {
    Preconditions.checkArgument(pb.getSerializedSize() <= MAXIMUM_DOCUMENT_LENGTH,
                                "Document length %d is greater than the maximum %d bytes",
                                pb.getSerializedSize(), MAXIMUM_DOCUMENT_LENGTH);
    if (pb.hasId()) {
      DocumentChecker.checkDocumentId(pb.getId());
    }
    Preconditions.checkArgument(pb.getFieldList() != null,
        "Null list of fields in document for indexing");
    return pb;
  }

  /**
   * @return the number of seconds since 2011/1/1
   */
  public static int getNumberOfSecondsSince() {
    long millisSince = Math.max(0L,
        (System.currentTimeMillis() - MILLIS_UP_TO_1ST_JAN_2011) / 1000L);
    Preconditions.checkArgument(millisSince <= Integer.MAX_VALUE,
        "API failure due to date conversion overflow");
    return (int) millisSince;
  }
}
