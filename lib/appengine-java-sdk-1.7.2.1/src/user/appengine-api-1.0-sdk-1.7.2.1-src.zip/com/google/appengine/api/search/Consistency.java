// Copyright 2010 Google Inc. All Rights Reserved.
package com.google.appengine.api.search;

/**
 * Supported consistency modes by indexes. When creating an index you may
 * request whether the index is {@link #GLOBAL} or {@link #PER_DOCUMENT}
 * consistent using this enum. An index with {@link #GLOBAL} consistency, when
 * searched, returns results with all changes prior to the search request,
 * committed. For {@link #PER_DOCUMENT} consistent indexes, a search result may
 * contain some out of date documents. However, any two changes to any document
 * stored in such an index are applied in the correct order. The benefit of
 * {@link #PER_DOCUMENT} consistent index is that it provides much higher index
 * document throughput than a globally consistent one.
 *
 * <p>Typically, you would use {@link #GLOBAL} consistency if organizing
 * personal user information, to reflect all changes known to the user in
 * any search results. The {@link #PER_DOCUMENT} consistency should be used
 * in indexes that amalgamate information from multiple sources, where no
 * single user is aware of all collected data.
 *
 */
public enum Consistency {
  /**
   * Globally consistent index, which guarantees that search returns
   * results including changes submitted before the latest search request.
   */
  GLOBAL(SearchServicePb.IndexSpec.Consistency.GLOBAL),

  /**
   * Document level consistent index, with search results that may not include
   * the latest changes to the index.
   */
  PER_DOCUMENT(SearchServicePb.IndexSpec.Consistency.PER_DOCUMENT);

  private final SearchServicePb.IndexSpec.Consistency consistency;

  private Consistency(SearchServicePb.IndexSpec.Consistency consistency) {
    this.consistency = consistency;
  }

  SearchServicePb.IndexSpec.Consistency getConsistency() {
    return consistency;
  }

  static Consistency fromProto(SearchServicePb.IndexSpec.Consistency consistency) {
    return consistency.equals(SearchServicePb.IndexSpec.Consistency.GLOBAL)
        ? GLOBAL : PER_DOCUMENT;
  }
}
