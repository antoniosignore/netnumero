

  package com.google.appengine.api.search;

import org.antlr.runtime.*;

public class ExpressionLexer extends Lexer {
    public static final int DOLLAR=33;
    public static final int LT=7;
    public static final int EXPONENT=28;
    public static final int LSQUARE=19;
    public static final int ASCII_LETTER=31;
    public static final int OCTAL_ESC=36;
    public static final int FLOAT=23;
    public static final int NAME_START=29;
    public static final int EOF=-1;
    public static final int LPAREN=17;
    public static final int INDEX=5;
    public static final int QUOTE=26;
    public static final int RPAREN=18;
    public static final int NAME=22;
    public static final int ESC_SEQ=27;
    public static final int PLUS=13;
    public static final int DIGIT=25;
    public static final int EQ=11;
    public static final int NE=12;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__40=40;
    public static final int GE=10;
    public static final int T__41=41;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int UNICODE_ESC=35;
    public static final int HEX_DIGIT=34;
    public static final int UNDERSCORE=32;
    public static final int INT=20;
    public static final int FN=6;
    public static final int MINUS=14;
    public static final int RSQUARE=21;
    public static final int PHRASE=24;
    public static final int WS=30;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int NEG=4;
    public static final int GT=9;
    public static final int DIV=16;
    public static final int TIMES=15;
    public static final int LE=8;

    public ExpressionLexer() {;}
    public ExpressionLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public ExpressionLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "java/com/google/appengine/api/search/Expression.g"; }

    public final void mT__37() throws RecognitionException {
        try {
            int _type = T__37;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('.');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__38() throws RecognitionException {
        try {
            int _type = T__38;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match(',');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__39() throws RecognitionException {
        try {
            int _type = T__39;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("abs");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__40() throws RecognitionException {
        try {
            int _type = T__40;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("count");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__41() throws RecognitionException {
        try {
            int _type = T__41;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("distance");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__42() throws RecognitionException {
        try {
            int _type = T__42;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("geopoint");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__43() throws RecognitionException {
        try {
            int _type = T__43;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("if");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__44() throws RecognitionException {
        try {
            int _type = T__44;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("len");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__45() throws RecognitionException {
        try {
            int _type = T__45;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("log");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__46() throws RecognitionException {
        try {
            int _type = T__46;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("max");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__47() throws RecognitionException {
        try {
            int _type = T__47;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("min");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__48() throws RecognitionException {
        try {
            int _type = T__48;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("pow");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__49() throws RecognitionException {
        try {
            int _type = T__49;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("snippet");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mINT() throws RecognitionException {
        try {
            int _type = INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0=='-') ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    {
                    match('-');

                    }
                    break;

            }

            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='0' && LA2_0<='9')) ) {
                    alt2=1;
                }

                switch (alt2) {
            	case 1 :
            	    {
            	    mDIGIT();

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mPHRASE() throws RecognitionException {
        try {
            int _type = PHRASE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            mQUOTE();
            loop3:
            do {
                int alt3=3;
                int LA3_0 = input.LA(1);

                if ( (LA3_0=='\\') ) {
                    alt3=1;
                }
                else if ( ((LA3_0>='\u0000' && LA3_0<='!')||(LA3_0>='#' && LA3_0<='[')||(LA3_0>=']' && LA3_0<='\uFFFF')) ) {
                    alt3=2;
                }

                switch (alt3) {
            	case 1 :
            	    {
            	    mESC_SEQ();

            	    }
            	    break;
            	case 2 :
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            mQUOTE();

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mFLOAT() throws RecognitionException {
        try {
            int _type = FLOAT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            int alt13=3;
            alt13 = dfa13.predict(input);
            switch (alt13) {
                case 1 :
                    {
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0=='-') ) {
                        alt4=1;
                    }
                    switch (alt4) {
                        case 1 :
                            {
                            match('-');

                            }
                            break;

                    }

                    int cnt5=0;
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( ((LA5_0>='0' && LA5_0<='9')) ) {
                            alt5=1;
                        }

                        switch (alt5) {
                    	case 1 :
                    	    {
                    	    mDIGIT();

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt5 >= 1 ) break loop5;
                                EarlyExitException eee =
                                    new EarlyExitException(5, input);
                                throw eee;
                        }
                        cnt5++;
                    } while (true);

                    match('.');
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( ((LA6_0>='0' && LA6_0<='9')) ) {
                            alt6=1;
                        }

                        switch (alt6) {
                    	case 1 :
                    	    {
                    	    mDIGIT();

                    	    }
                    	    break;

                    	default :
                    	    break loop6;
                        }
                    } while (true);

                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0=='E'||LA7_0=='e') ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            {
                            mEXPONENT();

                            }
                            break;

                    }

                    }
                    break;
                case 2 :
                    {
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0=='-') ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            {
                            match('-');

                            }
                            break;

                    }

                    match('.');
                    int cnt9=0;
                    loop9:
                    do {
                        int alt9=2;
                        int LA9_0 = input.LA(1);

                        if ( ((LA9_0>='0' && LA9_0<='9')) ) {
                            alt9=1;
                        }

                        switch (alt9) {
                    	case 1 :
                    	    {
                    	    mDIGIT();

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt9 >= 1 ) break loop9;
                                EarlyExitException eee =
                                    new EarlyExitException(9, input);
                                throw eee;
                        }
                        cnt9++;
                    } while (true);

                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0=='E'||LA10_0=='e') ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            {
                            mEXPONENT();

                            }
                            break;

                    }

                    }
                    break;
                case 3 :
                    {
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0=='-') ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            {
                            match('-');

                            }
                            break;

                    }

                    int cnt12=0;
                    loop12:
                    do {
                        int alt12=2;
                        int LA12_0 = input.LA(1);

                        if ( ((LA12_0>='0' && LA12_0<='9')) ) {
                            alt12=1;
                        }

                        switch (alt12) {
                    	case 1 :
                    	    {
                    	    mDIGIT();

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt12 >= 1 ) break loop12;
                                EarlyExitException eee =
                                    new EarlyExitException(12, input);
                                throw eee;
                        }
                        cnt12++;
                    } while (true);

                    mEXPONENT();

                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mNAME() throws RecognitionException {
        try {
            int _type = NAME;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            mNAME_START();
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0=='$'||(LA14_0>='0' && LA14_0<='9')||(LA14_0>='A' && LA14_0<='Z')||LA14_0=='_'||(LA14_0>='a' && LA14_0<='z')) ) {
                    alt14=1;
                }

                switch (alt14) {
            	case 1 :
            	    {
            	    if ( input.LA(1)=='$'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}

            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mLPAREN() throws RecognitionException {
        try {
            int _type = LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('(');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mRPAREN() throws RecognitionException {
        try {
            int _type = RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match(')');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mLSQUARE() throws RecognitionException {
        try {
            int _type = LSQUARE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('[');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mRSQUARE() throws RecognitionException {
        try {
            int _type = RSQUARE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match(']');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mPLUS() throws RecognitionException {
        try {
            int _type = PLUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('+');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mMINUS() throws RecognitionException {
        try {
            int _type = MINUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('-');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mTIMES() throws RecognitionException {
        try {
            int _type = TIMES;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('*');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mDIV() throws RecognitionException {
        try {
            int _type = DIV;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('/');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mLT() throws RecognitionException {
        try {
            int _type = LT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('<');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mLE() throws RecognitionException {
        try {
            int _type = LE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("<=");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mGT() throws RecognitionException {
        try {
            int _type = GT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('>');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mGE() throws RecognitionException {
        try {
            int _type = GE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match(">=");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mEQ() throws RecognitionException {
        try {
            int _type = EQ;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("==");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mNE() throws RecognitionException {
        try {
            int _type = NE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("!=");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mQUOTE() throws RecognitionException {
        try {
            int _type = QUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('\"');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            int cnt15=0;
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>='\t' && LA15_0<='\n')||LA15_0=='\r'||LA15_0==' ') ) {
                    alt15=1;
                }

                switch (alt15) {
            	case 1 :
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}

            	    }
            	    break;

            	default :
            	    if ( cnt15 >= 1 ) break loop15;
                        EarlyExitException eee =
                            new EarlyExitException(15, input);
                        throw eee;
                }
                cnt15++;
            } while (true);

            _channel = HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mEXPONENT() throws RecognitionException {
        try {
            {
            if ( input.LA(1)=='E'||input.LA(1)=='e' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0=='+'||LA16_0=='-') ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}

                    }
                    break;

            }

            int cnt17=0;
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>='0' && LA17_0<='9')) ) {
                    alt17=1;
                }

                switch (alt17) {
            	case 1 :
            	    {
            	    mDIGIT();

            	    }
            	    break;

            	default :
            	    if ( cnt17 >= 1 ) break loop17;
                        EarlyExitException eee =
                            new EarlyExitException(17, input);
                        throw eee;
                }
                cnt17++;
            } while (true);

            }

        }
        finally {
        }
    }

    public final void mNAME_START() throws RecognitionException {
        try {
            {
            if ( input.LA(1)=='$'||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            }

        }
        finally {
        }
    }

    public final void mASCII_LETTER() throws RecognitionException {
        try {
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            }

        }
        finally {
        }
    }

    public final void mDIGIT() throws RecognitionException {
        try {
            {
            matchRange('0','9');

            }

        }
        finally {
        }
    }

    public final void mDOLLAR() throws RecognitionException {
        try {
            {
            match('$');

            }

        }
        finally {
        }
    }

    public final void mUNDERSCORE() throws RecognitionException {
        try {
            {
            match('_');

            }

        }
        finally {
        }
    }

    public final void mHEX_DIGIT() throws RecognitionException {
        try {
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='F')||(input.LA(1)>='a' && input.LA(1)<='f') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            }

        }
        finally {
        }
    }

    public final void mESC_SEQ() throws RecognitionException {
        try {
            int alt18=3;
            int LA18_0 = input.LA(1);

            if ( (LA18_0=='\\') ) {
                switch ( input.LA(2) ) {
                case '\"':
                case '\'':
                case '\\':
                case 'b':
                case 'f':
                case 'n':
                case 'r':
                case 't':
                    {
                    alt18=1;
                    }
                    break;
                case 'u':
                    {
                    alt18=2;
                    }
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                    {
                    alt18=3;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 18, 1, input);

                    throw nvae;
                }

            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    {
                    match('\\');
                    if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}

                    }
                    break;
                case 2 :
                    {
                    mUNICODE_ESC();

                    }
                    break;
                case 3 :
                    {
                    mOCTAL_ESC();

                    }
                    break;

            }
        }
        finally {
        }
    }

    public final void mOCTAL_ESC() throws RecognitionException {
        try {
            int alt19=3;
            int LA19_0 = input.LA(1);

            if ( (LA19_0=='\\') ) {
                int LA19_1 = input.LA(2);

                if ( ((LA19_1>='0' && LA19_1<='3')) ) {
                    int LA19_2 = input.LA(3);

                    if ( ((LA19_2>='0' && LA19_2<='7')) ) {
                        int LA19_4 = input.LA(4);

                        if ( ((LA19_4>='0' && LA19_4<='7')) ) {
                            alt19=1;
                        }
                        else {
                            alt19=2;}
                    }
                    else {
                        alt19=3;}
                }
                else if ( ((LA19_1>='4' && LA19_1<='7')) ) {
                    int LA19_3 = input.LA(3);

                    if ( ((LA19_3>='0' && LA19_3<='7')) ) {
                        alt19=2;
                    }
                    else {
                        alt19=3;}
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 19, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    {
                    match('\\');
                    {
                    matchRange('0','3');

                    }

                    {
                    matchRange('0','7');

                    }

                    {
                    matchRange('0','7');

                    }

                    }
                    break;
                case 2 :
                    {
                    match('\\');
                    {
                    matchRange('0','7');

                    }

                    {
                    matchRange('0','7');

                    }

                    }
                    break;
                case 3 :
                    {
                    match('\\');
                    {
                    matchRange('0','7');

                    }

                    }
                    break;

            }
        }
        finally {
        }
    }

    public final void mUNICODE_ESC() throws RecognitionException {
        try {
            {
            match('\\');
            match('u');
            mHEX_DIGIT();
            mHEX_DIGIT();
            mHEX_DIGIT();
            mHEX_DIGIT();

            }

        }
        finally {
        }
    }

    public void mTokens() throws RecognitionException {
        int alt20=33;
        alt20 = dfa20.predict(input);
        switch (alt20) {
            case 1 :
                {
                mT__37();

                }
                break;
            case 2 :
                {
                mT__38();

                }
                break;
            case 3 :
                {
                mT__39();

                }
                break;
            case 4 :
                {
                mT__40();

                }
                break;
            case 5 :
                {
                mT__41();

                }
                break;
            case 6 :
                {
                mT__42();

                }
                break;
            case 7 :
                {
                mT__43();

                }
                break;
            case 8 :
                {
                mT__44();

                }
                break;
            case 9 :
                {
                mT__45();

                }
                break;
            case 10 :
                {
                mT__46();

                }
                break;
            case 11 :
                {
                mT__47();

                }
                break;
            case 12 :
                {
                mT__48();

                }
                break;
            case 13 :
                {
                mT__49();

                }
                break;
            case 14 :
                {
                mINT();

                }
                break;
            case 15 :
                {
                mPHRASE();

                }
                break;
            case 16 :
                {
                mFLOAT();

                }
                break;
            case 17 :
                {
                mNAME();

                }
                break;
            case 18 :
                {
                mLPAREN();

                }
                break;
            case 19 :
                {
                mRPAREN();

                }
                break;
            case 20 :
                {
                mLSQUARE();

                }
                break;
            case 21 :
                {
                mRSQUARE();

                }
                break;
            case 22 :
                {
                mPLUS();

                }
                break;
            case 23 :
                {
                mMINUS();

                }
                break;
            case 24 :
                {
                mTIMES();

                }
                break;
            case 25 :
                {
                mDIV();

                }
                break;
            case 26 :
                {
                mLT();

                }
                break;
            case 27 :
                {
                mLE();

                }
                break;
            case 28 :
                {
                mGT();

                }
                break;
            case 29 :
                {
                mGE();

                }
                break;
            case 30 :
                {
                mEQ();

                }
                break;
            case 31 :
                {
                mNE();

                }
                break;
            case 32 :
                {
                mQUOTE();

                }
                break;
            case 33 :
                {
                mWS();

                }
                break;

        }

    }

    protected DFA13 dfa13 = new DFA13(this);
    protected DFA20 dfa20 = new DFA20(this);
    static final String DFA13_eotS =
        "\6\uffff";
    static final String DFA13_eofS =
        "\6\uffff";
    static final String DFA13_minS =
        "\1\55\2\56\3\uffff";
    static final String DFA13_maxS =
        "\2\71\1\145\3\uffff";
    static final String DFA13_acceptS =
        "\3\uffff\1\2\1\1\1\3";
    static final String DFA13_specialS =
        "\6\uffff}>";
    static final String[] DFA13_transitionS = {
            "\1\1\1\3\1\uffff\12\2",
            "\1\3\1\uffff\12\2",
            "\1\4\1\uffff\12\2\13\uffff\1\5\37\uffff\1\5",
            "",
            "",
            ""
    };

    static final short[] DFA13_eot = DFA.unpackEncodedString(DFA13_eotS);
    static final short[] DFA13_eof = DFA.unpackEncodedString(DFA13_eofS);
    static final char[] DFA13_min = DFA.unpackEncodedStringToUnsignedChars(DFA13_minS);
    static final char[] DFA13_max = DFA.unpackEncodedStringToUnsignedChars(DFA13_maxS);
    static final short[] DFA13_accept = DFA.unpackEncodedString(DFA13_acceptS);
    static final short[] DFA13_special = DFA.unpackEncodedString(DFA13_specialS);
    static final short[][] DFA13_transition;

    static {
        int numStates = DFA13_transitionS.length;
        DFA13_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA13_transition[i] = DFA.unpackEncodedString(DFA13_transitionS[i]);
        }
    }

    class DFA13 extends DFA {

        public DFA13(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 13;
            this.eot = DFA13_eot;
            this.eof = DFA13_eof;
            this.min = DFA13_min;
            this.max = DFA13_max;
            this.accept = DFA13_accept;
            this.special = DFA13_special;
            this.transition = DFA13_transition;
        }
        public String getDescription() {
            return "142:1: FLOAT : ( ( '-' )? ( DIGIT )+ '.' ( DIGIT )* ( EXPONENT )? | ( '-' )? '.' ( DIGIT )+ ( EXPONENT )? | ( '-' )? ( DIGIT )+ EXPONENT );";
        }
    }
    static final String DFA20_eotS =
        "\1\uffff\1\34\1\uffff\11\17\1\51\1\52\1\53\10\uffff\1\56\1\60\5"+
        "\uffff\4\17\1\65\6\17\10\uffff\1\74\3\17\1\uffff\1\100\1\101\1\102"+
        "\1\103\1\104\1\17\1\uffff\3\17\5\uffff\1\17\1\112\3\17\1\uffff\5"+
        "\17\1\123\1\124\1\125\3\uffff";
    static final String DFA20_eofS =
        "\126\uffff";
    static final String DFA20_minS =
        "\1\11\1\60\1\uffff\1\142\1\157\1\151\1\145\1\146\1\145\1\141\1\157"+
        "\1\156\2\56\1\0\10\uffff\2\75\5\uffff\1\163\1\165\1\163\1\157\1"+
        "\44\1\156\1\147\1\170\1\156\1\167\1\151\10\uffff\1\44\1\156\1\164"+
        "\1\160\1\uffff\5\44\1\160\1\uffff\1\164\1\141\1\157\5\uffff\1\160"+
        "\1\44\1\156\1\151\1\145\1\uffff\1\143\1\156\1\164\1\145\1\164\3"+
        "\44\3\uffff";
    static final String DFA20_maxS =
        "\1\172\1\71\1\uffff\1\142\1\157\1\151\1\145\1\146\1\157\1\151\1"+
        "\157\1\156\1\71\1\145\1\uffff\10\uffff\2\75\5\uffff\1\163\1\165"+
        "\1\163\1\157\1\172\1\156\1\147\1\170\1\156\1\167\1\151\10\uffff"+
        "\1\172\1\156\1\164\1\160\1\uffff\5\172\1\160\1\uffff\1\164\1\141"+
        "\1\157\5\uffff\1\160\1\172\1\156\1\151\1\145\1\uffff\1\143\1\156"+
        "\1\164\1\145\1\164\3\172\3\uffff";
    static final String DFA20_acceptS =
        "\2\uffff\1\2\14\uffff\1\21\1\22\1\23\1\24\1\25\1\26\1\30\1\31\2"+
        "\uffff\1\36\1\37\1\41\1\1\1\20\13\uffff\1\27\1\16\1\40\1\17\1\33"+
        "\1\32\1\35\1\34\4\uffff\1\7\6\uffff\1\3\3\uffff\1\10\1\11\1\12\1"+
        "\13\1\14\5\uffff\1\4\10\uffff\1\15\1\5\1\6";
    static final String DFA20_specialS =
        "\16\uffff\1\0\107\uffff}>";
    static final String[] DFA20_transitionS = {
            "\2\33\2\uffff\1\33\22\uffff\1\33\1\32\1\16\1\uffff\1\17\3\uffff"+
            "\1\20\1\21\1\25\1\24\1\2\1\14\1\1\1\26\12\15\2\uffff\1\27\1"+
            "\31\1\30\2\uffff\32\17\1\22\1\uffff\1\23\1\uffff\1\17\1\uffff"+
            "\1\3\1\17\1\4\1\5\2\17\1\6\1\17\1\7\2\17\1\10\1\11\2\17\1\12"+
            "\2\17\1\13\7\17",
            "\12\35",
            "",
            "\1\36",
            "\1\37",
            "\1\40",
            "\1\41",
            "\1\42",
            "\1\43\11\uffff\1\44",
            "\1\45\7\uffff\1\46",
            "\1\47",
            "\1\50",
            "\1\35\1\uffff\12\15",
            "\1\35\1\uffff\12\15\13\uffff\1\35\37\uffff\1\35",
            "\0\54",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\55",
            "\1\57",
            "",
            "",
            "",
            "",
            "",
            "\1\61",
            "\1\62",
            "\1\63",
            "\1\64",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\66",
            "\1\67",
            "\1\70",
            "\1\71",
            "\1\72",
            "\1\73",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\75",
            "\1\76",
            "\1\77",
            "",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\105",
            "",
            "\1\106",
            "\1\107",
            "\1\110",
            "",
            "",
            "",
            "",
            "",
            "\1\111",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\113",
            "\1\114",
            "\1\115",
            "",
            "\1\116",
            "\1\117",
            "\1\120",
            "\1\121",
            "\1\122",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "\1\17\13\uffff\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32"+
            "\17",
            "",
            "",
            ""
    };

    static final short[] DFA20_eot = DFA.unpackEncodedString(DFA20_eotS);
    static final short[] DFA20_eof = DFA.unpackEncodedString(DFA20_eofS);
    static final char[] DFA20_min = DFA.unpackEncodedStringToUnsignedChars(DFA20_minS);
    static final char[] DFA20_max = DFA.unpackEncodedStringToUnsignedChars(DFA20_maxS);
    static final short[] DFA20_accept = DFA.unpackEncodedString(DFA20_acceptS);
    static final short[] DFA20_special = DFA.unpackEncodedString(DFA20_specialS);
    static final short[][] DFA20_transition;

    static {
        int numStates = DFA20_transitionS.length;
        DFA20_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA20_transition[i] = DFA.unpackEncodedString(DFA20_transitionS[i]);
        }
    }

    class DFA20 extends DFA {

        public DFA20(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 20;
            this.eot = DFA20_eot;
            this.eof = DFA20_eof;
            this.min = DFA20_min;
            this.max = DFA20_max;
            this.accept = DFA20_accept;
            this.special = DFA20_special;
            this.transition = DFA20_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__37 | T__38 | T__39 | T__40 | T__41 | T__42 | T__43 | T__44 | T__45 | T__46 | T__47 | T__48 | T__49 | INT | PHRASE | FLOAT | NAME | LPAREN | RPAREN | LSQUARE | RSQUARE | PLUS | MINUS | TIMES | DIV | LT | LE | GT | GE | EQ | NE | QUOTE | WS );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 :
                        int LA20_14 = input.LA(1);

                        s = -1;
                        if ( ((LA20_14>='\u0000' && LA20_14<='\uFFFF')) ) {s = 44;}

                        else s = 43;

                        if ( s>=0 ) return s;
                        break;
            }
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 20, _s, input);
            error(nvae);
            throw nvae;
        }
    }

}
