// Copyright 2011 Google Inc. All rights reserved.
package com.google.appengine.api.search;

import java.util.ArrayList;
import java.util.List;

/**
 * Thrown to indicate that a search service failure occurred while adding
 * documents to the index.
 *
 * @deprecated As of 1.6.5, replaced by {@link AddException}.
 */
@Deprecated
public class AddDocumentsException extends SearchBaseException {
  private static final long serialVersionUID = 3608247775865189592L;

  private final List<OperationResult> results;
  private final List<String> documentIds;

  /**
   * Constructs an exception when some error occurred in
   * the search service when adding some documents to the index.
   *
   * @param operationResult the error code and message detail associated with
   * the failure
   */
  public AddDocumentsException(OperationResult operationResult) {
    this(operationResult, new ArrayList<OperationResult>(), new ArrayList<String>());
  }

  /**
   * Constructs an exception when some error occurred in
   * the search service when adding some documents to the index.
   *
   * @param operationResult the error code and message detail associated with
   * the failure
   * @param results the list of {@link OperationResult} where each result is
   * associated with a document that was requested to be added to the index
   * @param documentIds the list of Ids of {@link Document} requested to be
   * added to the index. The search service may provide an Id if none was given
   * for a Document
   */
  public AddDocumentsException(OperationResult operationResult,
      List<OperationResult> results, List<String> documentIds) {
    super(operationResult);
    this.results = results;
    this.documentIds = documentIds;
  }

  /**
   * @return the list of {@link OperationResult} where each result is
   * associated with a document that was requested to be added to the index
   */
  public List<OperationResult> getResults() {
    return results;
  }

  /**
   * Deprecated. Use {@link AddException#getIds()}.
   *
   * @return the list of Ids of documents that were requested to be added to
   * the index
   */
  @Deprecated
  public List<String> getDocumentIds() {
    return documentIds;
  }
}
