// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.appengine.api.search.query;

import org.antlr.runtime.BitSet;
import org.antlr.runtime.IntStream;
import org.antlr.runtime.MismatchedTokenException;
import org.antlr.runtime.TokenRewriteStream;
import org.antlr.runtime.RecognitionException;

/**
 * A factory which produces {@link QueryParser QueryParsers} for a given
 * token rewrite stream.
 *
 */
public class QueryParserFactory {
  public QueryParser newParser(TokenRewriteStream tokens) {
    return new QueryParser(tokens) {
      @Override
      public Object recoverFromMismatchedSet(IntStream input,
          RecognitionException e, BitSet follow) throws RecognitionException {
        throw e;
      }

      @Override
      protected Object recoverFromMismatchedToken(IntStream input, int ttype, BitSet follow)
          throws RecognitionException {
        throw new MismatchedTokenException(ttype, input);
      }
    };
  }
}
