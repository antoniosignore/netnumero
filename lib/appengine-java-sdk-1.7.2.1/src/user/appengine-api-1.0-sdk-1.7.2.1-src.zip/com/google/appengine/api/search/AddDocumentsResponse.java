// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.appengine.api.search;

import com.google.appengine.api.search.checkers.Preconditions;

import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Represents a result of adding a list of {@link Document} to the index. The
 * response contains a list of {@link OperationResult} indicating success
 * or not of adding each of the {@link Document Documents}, and a
 * list of Id of the {@link Document Documents} which are those
 * given in the request or allocated by the search service to those
 * {@link Document Documents} which do not have an Id supplied.
 *
 * @deprecated As of 1.6.5, replaced by {@link AddResponse}.
 */
@Deprecated
public class AddDocumentsResponse implements Iterable<OperationResult>, Serializable {
  private static final long serialVersionUID = 1189234703739911898L;

  private final List<OperationResult> results;
  private final List<String> documentIds;

  /**
   * Creates a {@link AddDocumentsResponse} by specifying a list of
   * {@link OperationResult} and a list of document ids.
   *
   * @param results a list of {@link OperationResult} that indicate the
   * success or not adding each {@link Document}
   * @param documentIds a list of Id of the {@link Document Documents}
   * that were requested to be added. The search service may supply Ids for
   * those Documents where none was supplied
   */
  AddDocumentsResponse(List<OperationResult> results,
      List<String> documentIds) {
    this.results = Collections.unmodifiableList(
        Preconditions.checkNotNull(results, "results cannot be null"));
    this.documentIds = Collections.unmodifiableList(
        Preconditions.checkNotNull(documentIds, "documentIds cannot be null"));
  }

  @Override
  public Iterator<OperationResult> iterator() {
    return results.iterator();
  }

  /**
   * @return an unmodifiable list of {@link OperationResult} indicating
   * whether each {@link Document} was added or not
   */
  public List<OperationResult> getResults() {
    return results;
  }

  /**
   * @return an unmodifiable list of {@link Document} Ids
   */
  @Deprecated
  public List<String> getDocumentIds() {
    return documentIds;
  }

  @Override
  public String toString() {
    return String.format("AddDocumentsResponse(results=%s, documentIds=%s)",
        Util.iterableToString(results, 0), Util.iterableToString(documentIds, 0));
  }
}
