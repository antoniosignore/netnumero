// Copyright 2010 Google Inc. All rights reserved.
package com.google.appengine.api.search;

/**
 * Thrown to indicate that a search service failure occurred.
 *
 * @deprecated As of 1.7.1, replaced by {@link SearchServiceException}.
 */
@Deprecated
public class InternalFailureException extends RuntimeException {
  private static final long serialVersionUID = 6323191554940253153L;

  /**
   * Constructs an exception which indicates an internal error
   * occurred in the search service.
   *
   * @param detail the error message detail to associate with the
   * internal error
   */
  public InternalFailureException(String detail) {
    super(detail);
  }

  /**
   * Constructs an exception which indicates an internal error
   * occurred in the search service.
   *
   * @param detail the error message detail to associate with the
   * internal error
   * @param e the causing {@link Exception}
   */
  public InternalFailureException(String detail, Exception e) {
    super(detail, e);
  }
}
