// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.appengine.api.search;

import com.google.appengine.api.search.checkers.IndexChecker;

import java.util.concurrent.Future;

/**
 * An Index allows synchronous and asynchronous adding and deleting of
 * {@link Document Documents} as well as synchronous and asynchronous
 * searching for Documents for a given {@link Query}. The following
 * code fragment shows how to add documents, then search the index for
 * documents matching a query.
 *<p>
 *<pre>
 *  // Get the SearchService for the default namespace
 *  SearchService searchService = SearchServiceFactory.getSearchService();
 *  // Get the index. If not yet created, create it.
 *  Index index = searchService.getIndex(
 *      IndexSpec.newBuilder()
 *          .setIndexName("indexName")
 *          .setConsistency(Consistency.PER_DOCUMENT));
 *
 *  // Create a document.
 *  Document document = Document.newBuilder()
 *      .setId("documentId")
 *      .addField(Field.newBuilder().setName("subject").setText("my first email"))
 *      .addField(Field.newBuilder().setName("body")
 *           .setHTML("&lt;html&gt;some content here&lt;/html&gt;")
 *      .build();
 *
 *  // Add the document.
 *  try {
 *    index.add(document);
 *  } catch (AddException e) {
 *    if (StatusCode.TRANSIENT_ERROR.equals(e.getOperationResult().getCode())) {
 *      // retry adding document
 *    }
 *  }
 *
 *  // Query the index.
 *  try {
 *    Results&lt;ScoredDocument&gt; results =
 *        index.search(Query.newBuilder().build("subject:first body:here"));
 *
 *    // Iterate through the search results.
 *    for (ScoredDocument document : results) {
 *      // display results
 *    }
 *  } catch (SearchException e) {
 *    if (StatusCode.TRANSIENT_ERROR.equals(e.getOperationResult().getCode())) {
 *      // retry
 *    }
 *  }
 *</pre>
 *
 */
public interface Index {

  /**
   * @return the name of the index
   */
  String getName();

  /**
   * @return the namespace of the index name
   */
  String getNamespace();

  /**
   * @return the consistency mode of this index
   */
  Consistency getConsistency();

  /**
   * @see {@link #remove(String...)}
   */
  Future<Void> removeAsync(String... documentId);

  /**
   * @see {@link #remove(String...)}
   */
  Future<Void> removeAsync(Iterable<String> documentIds);

  /**
   * @see {@link #add(Document...)}
   */
  Future<AddResponse> addAsync(Document... document);

  /**
   * @see {@link #add(Document...)}
   */
  Future<AddResponse> addAsync(Iterable<Document> documents);

  /**
   * @see use {@link #search(String)}
   */
  Future<Results<ScoredDocument>> searchAsync(String query);

  /**
   * @see {@link #search(Query)}
   */
  Future<Results<ScoredDocument>> searchAsync(Query query);

  /**
   * @see {@link #listDocuments(ListRequest)}
   */
  Future<ListResponse<Document>> listDocumentsAsync(ListRequest request);

  /**
   * Delete documents for the given document ids from the index if
   * they are in the index.
   *
   * @param  documentIds the ids of documents to remove
   * @throws RemoveException if there is a failure in the search
   * service deleting documents
   * @throws IllegalArgumentException if some document id is invalid
   */
  void remove(String... documentIds);

  /**
   * @see {@link #remove(String...)}
   */
  void remove(Iterable<String> documentIds);

  /**
   * Add the documents to the index, updating any document that is already
   * present.
   *
   * @param  documents the documents to add to the index
   * @return an {@link AddResponse} containing the result of
   * the add operations indicating success or failure as well as the document
   * ids. The search service will allocate document ids for documents which
   * have none provided
   * @throws AddException if there is a failure in the search
   * service adding documents
   * @throws IllegalArgumentException if some document is invalid or
   * more than {@link IndexChecker#MAXIMUM_DOCS_PER_REQUEST} documents
   * requested to be added
   */
  AddResponse add(Document... documents);

  /**
   * @see {@link #add(Document...)}
   */
  AddResponse add(Iterable<Document> documents);

  /**
   * Gets a {@link Document} for the given document Id.
   *
   * @param documentId the identifier for the document to retrieve
   * @return the associated {@link Document}. can be null
   */
  Document get(String documentId);

  /**
   * @see {@link #search(Query)}
   */
  Results<ScoredDocument> search(String query);

  /**
   * Search the index for documents matching the query. The query
   * must specify a query string, and optionally, how many documents
   * are requested, how the results are to be sorted, scored and
   * which fields are to be returned.
   *
   * @param  query the fully specified {@link Query} object
   * @return a {@link Results} containing
   * {@link ScoredDocument ScoredDocuments}
   * @throws IllegalArgumentException if the query is invalid
   * @throws SearchQueryException if the query string is invalid
   * @throws SearchException if there is a failure in the search service
   * performing the search
   */
  Results<ScoredDocument> search(Query query);

  /**
   * Lists the index's documents, in document Id order.
   *
   * @param  request contains various options restricting which documents are
   * returned.
   * @return a {@link ListResponse&lt;Document&gt;} containing a list of
   * documents from the index
   * @throws IllegalArgumentException if the list request is invalid
   */
  ListResponse<Document> listDocuments(ListRequest request);

  /**
   * @return the {@link Schema} describing supported document field names and
   * {@link Field.FieldType}s supported for those field names. This schema
   * will only be populated if the {@link ListIndexesRequest#isSchemaFetched}
   * is set to true on an {@link SearchService#listIndexes} request
   */
  Schema getSchema();
}
