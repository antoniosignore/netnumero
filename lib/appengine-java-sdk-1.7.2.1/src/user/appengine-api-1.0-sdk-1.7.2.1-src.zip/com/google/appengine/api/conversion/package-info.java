// Copyright 2011 Google Inc.  All rights reserved.

/**
 * Provides a service for format conversion of HTML, PDF, text, images
 * and image optical character recognition (OCR).
 *
 * @see com.google.appengine.api.conversion.ConversionService
 * @see <a href="http://code.google.com/appengine/docs/java/conversion/">
 * The Conversion Java API in the <em>Google App Engine Developer's Guide</em></a>.
 */
package com.google.appengine.api.conversion;
