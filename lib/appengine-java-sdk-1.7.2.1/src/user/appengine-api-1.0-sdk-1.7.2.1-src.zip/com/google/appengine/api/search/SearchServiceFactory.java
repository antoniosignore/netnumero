// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.appengine.api.search;

import com.google.appengine.api.NamespaceManager;

/**
 * An factory that creates default implementation of {@link SearchService}.
 *
 * <pre>
 *   SearchService search = SearchServiceFactory.getSearchService();
 * </pre>
 *
 * Optionally, you may pass the namespace to restrict resources
 * associated with usage of the SearchService:
 *
 * <pre>
 *   SearchService acmeSearchService = SearchServiceFactory.getSearchService("acme");
 * </pre>
 *
 */
public final class SearchServiceFactory {

  static SearchApiHelper apiHelper = new SearchApiHelper();

  /**
   * Returns an instance of the {@link SearchService}.  The instance
   * will exist either in the namespace set on the {@link
   * NamespaceManager}, or, if none was set, in an empty namespace.
   *
   * @return the default implementation of {@link SearchService}.
   */
  static SearchService getSearchService(SearchApiHelper helper) {
    return new SearchServiceImpl(helper == null ? apiHelper : helper, NamespaceManager.get());
  }

  public static SearchService getSearchService() {
    return getSearchService(apiHelper);
  }

  /**
   * Returns an instance of the {@link SearchService}.  The instance
   * will exist in the user provided namespace. The namespace must be
   * valid, as per {@link NamespaceManager#validateNamespace(String)}
   * method.
   *
   * @param namespace a namespace to be assigned to the returned
   * search service.
   * @return the default implementation of {@link SearchService}.
   * @throws IllegalArgumentException if the namespace is invalid
   */
  public static SearchService getSearchService(String namespace) {
    NamespaceManager.validateNamespace(namespace);
    return new SearchServiceImpl(apiHelper, namespace);
  }

  /**
   * No instances of this class may be created.
   */
  private SearchServiceFactory() {}
}
