// Copyright 2011 Google Inc. All rights reserved.
package com.google.appengine.api.search;

import java.util.ArrayList;
import java.util.List;

/**
 * Thrown to indicate that a search service failure occurred while adding
 * objects to the index.
 *
 */
public class AddException extends SearchBaseException {
  private static final long serialVersionUID = 3608247775865189592L;

  private final List<OperationResult> results;
  private final List<String> ids;

  /**
   * Constructs an exception when some error occurred in
   * the search service when adding some objects to the index.
   *
   * @param operationResult the error code and message detail associated with
   * the failure
   */
  public AddException(OperationResult operationResult) {
    this(operationResult, new ArrayList<OperationResult>(), new ArrayList<String>());
  }

  /**
   * Constructs an exception when some error occurred in
   * the search service when adding some objects to the index.
   *
   * @param operationResult the error code and message detail associated with
   * the failure
   * @param results the list of {@link OperationResult} where each result is
   * associated with an object that was requested to be added to the index
   * @param ids the list of Ids of the object requested to be
   * added to the index. The search service may provide an Id if none was given
   * for an object
   */
  public AddException(OperationResult operationResult,
      List<OperationResult> results, List<String> ids) {
    super(operationResult);
    this.results = results;
    this.ids = ids;
  }

  /**
   * @return the list of {@link OperationResult} where each result is
   * associated with a request to be add to the index
   */
  public List<OperationResult> getResults() {
    return results;
  }

  /**
   * @return the list of Ids of objects that were requested to be added to
   * the index
   */
  public List<String> getIds() {
    return ids;
  }
}
